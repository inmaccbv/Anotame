// Importaciones de módulos y servicios necesarios
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from "@angular/forms";

import { UsuariosService } from '../../services/usuarios.service';
import { AlertController, ToastController } from '@ionic/angular';
import { EmpresaService } from 'src/app/services/empresa.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  ionicForm!: FormGroup;
  submitted = false;
  registros: any;
  rol!: any;
  nombreEmpresa: string | null;
  empresas: any[] = [];

  constructor(
    public formBuilder: FormBuilder,
    public userRegis: UsuariosService,
    private empresaService: EmpresaService, 
    private toastController: ToastController,
    public alertController: AlertController
  ) {
    this.ionicForm = this.formBuilder.group({
      nombre: new FormControl("", Validators.compose([Validators.required])),
      apellido: new FormControl("", Validators.compose([Validators.required])),
      email: new FormControl("", Validators.compose([Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])),
      password: new FormControl("", Validators.compose([Validators.required, Validators.minLength(6)])),
      confirmPassword: new FormControl("", Validators.compose([Validators.required, Validators.minLength(6)])),
      rol: new FormControl("administrador", Validators.compose([Validators.required])),
      empresa: new FormControl("", Validators.compose([Validators.required])),
    }, {
      validators: this.MustMatch('password', 'confirmPassword') // Validador personalizado para comparar contraseñas
    });

    this.nombreEmpresa = localStorage.getItem('empresa');
    this.ionicForm.controls['empresa'].setValue(this.nombreEmpresa);
  }

  ngOnInit() {
    this.getEmpresas();
  }

 

  get f() {
    return this.ionicForm.controls;
  }

  MustMatch(password: any, confirmPassword: any) {
    return (formGroup: FormGroup) => {
      const passwordcontrol = formGroup.controls[password];
      const confirmPasswordControl = formGroup.controls[confirmPassword];

      if (confirmPasswordControl.errors && !confirmPasswordControl.errors['MustMatch']) {
        return;
      }

      if (passwordcontrol.value !== confirmPasswordControl.value) {
        confirmPasswordControl.setErrors({ MustMatch: true });
      } else {
        confirmPasswordControl.setErrors(null);
      }
    };
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  alert(event: any) {
    console.log(event.target);

    const datos = {
      nombre: event.target.nombre,
      apellido: event.target.apellido,
      email: event.target.email,
      password: event.target.password,
      rol: event.target.rol,
    }

    console.log(datos);

    this.submitted = true;

    // Detenerse aquí si el formulario no es válido
    if (this.ionicForm.invalid) {
      return;
    }
    // Mostrar los valores del formulario en caso de éxito
   // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.ionicForm.value, null, 4));
  }

  async getEmpresas() {
    try {
      const response = await this.userRegis.getEmpresas().toPromise();

      console.log('Respuesta de getEmpresas:', response);

      // Verifica si la respuesta es un array
      if (Array.isArray(response)) {
        this.empresas = response;
      } else {
        this.presentToast('No se encontraron empresas.');
      }
    } catch (error) {
      console.error('Error al obtener la lista de empresas:', error);
      this.presentToast('Error al obtener la lista de empresas.');
    }
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'top'
    });
    toast.present();
  }

  enviarDatos() {
    console.log('Enviando datos:', this.ionicForm.value);
  
    this.submitted = true;
  
    if (this.ionicForm.invalid) {
      console.log('Formulario no válido. Deteniendo envío de datos.');
      return;
    }
  
    this.userRegis.registroUsuario(this.ionicForm.value).subscribe(
      (ans) => {
        console.log('Respuesta del servidor:', ans);
  
        this.registros = ans;
  
        console.log('Datos de registros:', this.registros['data']);
        console.log('Texto de registros:', this.registros['texto']);
        console.log('Authorized de registros:', this.registros['authorized']);
  
        if (this.registros['authorized'] === 'NO') {
          console.log('Mostrando alerta de error...');
          // Llama al método mostrarAlertaNO con el mensaje específico
          this.mostrarAlertaNO('Error', 'Email ya registrado');
        } else {
          console.log('Mostrando alerta de éxito...');
          // Llama al método mostrarAlertaOK con el mensaje específico
          this.mostrarAlertaOK('Enhorabuena', 'Usuario creado correctamente');
        }
      },
      (error) => {
        console.error('Error en la solicitud:', error);
        console.log('Mostrando alerta de error en la solicitud...');
        // En caso de un error en la solicitud, muestra una alerta de error genérica
        this.mostrarAlertaNO('Error', 'Email ya registrado');
      }
    );
  }
  
  async mostrarAlertaOK(titulo: string, mensaje: string) {
    const alert = await this.alertController.create({
      header: titulo,
      message: mensaje,
      buttons: [{
        text: 'OK',
        handler: () => {
          window.location.href = '';
        }
      }],
      cssClass: 'custom-alert-header'
    });
  
    await alert.present();
  }
  
  async mostrarAlertaNO(titulo: string, mensaje: string) {
    const alert = await this.alertController.create({
      header: titulo,
      message: mensaje,
      buttons: ['OK'],
      cssClass: 'custom-alert-header'
    });
  
    await alert.present();
  }
}